﻿namespace CPT_Project_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDisplayBox = new System.Windows.Forms.Label();
            this.btnGroceryStores = new System.Windows.Forms.Button();
            this.btnSportsCentres = new System.Windows.Forms.Button();
            this.btnGasStations = new System.Windows.Forms.Button();
            this.btnPharmacy = new System.Windows.Forms.Button();
            this.lblDisplayBox1 = new System.Windows.Forms.Label();
            this.lblDetails1 = new System.Windows.Forms.Label();
            this.lblDetails2 = new System.Windows.Forms.Label();
            this.lblDetails3 = new System.Windows.Forms.Label();
            this.lbldetails4 = new System.Windows.Forms.Label();
            this.lblDetails5 = new System.Windows.Forms.Label();
            this.lbldetails6 = new System.Windows.Forms.Label();
            this.Rangebox = new System.Windows.Forms.TextBox();
            this.Resetbtn = new System.Windows.Forms.Button();
            this.Startbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDisplayBox
            // 
            this.lblDisplayBox.AutoSize = true;
            this.lblDisplayBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lblDisplayBox.Location = new System.Drawing.Point(8, 5);
            this.lblDisplayBox.Name = "lblDisplayBox";
            this.lblDisplayBox.Size = new System.Drawing.Size(373, 13);
            this.lblDisplayBox.TabIndex = 0;
            this.lblDisplayBox.Text = "GROCERY SPORTS COMPLEXES, GAS STATIONS, PHARMACY STORES";
            // 
            // btnGroceryStores
            // 
            this.btnGroceryStores.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnGroceryStores.Location = new System.Drawing.Point(374, 106);
            this.btnGroceryStores.Name = "btnGroceryStores";
            this.btnGroceryStores.Size = new System.Drawing.Size(170, 59);
            this.btnGroceryStores.TabIndex = 1;
            this.btnGroceryStores.Text = "Grocery Stores";
            this.btnGroceryStores.UseVisualStyleBackColor = false;
            this.btnGroceryStores.Click += new System.EventHandler(this.btnGroceryStores_Click);
            // 
            // btnSportsCentres
            // 
            this.btnSportsCentres.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSportsCentres.Location = new System.Drawing.Point(378, 191);
            this.btnSportsCentres.Name = "btnSportsCentres";
            this.btnSportsCentres.Size = new System.Drawing.Size(161, 59);
            this.btnSportsCentres.TabIndex = 2;
            this.btnSportsCentres.Text = "Sports Centers";
            this.btnSportsCentres.UseVisualStyleBackColor = false;
            this.btnSportsCentres.Click += new System.EventHandler(this.btnSportsCentres_Click);
            // 
            // btnGasStations
            // 
            this.btnGasStations.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnGasStations.Location = new System.Drawing.Point(368, 373);
            this.btnGasStations.Name = "btnGasStations";
            this.btnGasStations.Size = new System.Drawing.Size(175, 56);
            this.btnGasStations.TabIndex = 3;
            this.btnGasStations.Text = "Gas Stations";
            this.btnGasStations.UseVisualStyleBackColor = false;
            this.btnGasStations.Click += new System.EventHandler(this.btnGasStations_Click);
            // 
            // btnPharmacy
            // 
            this.btnPharmacy.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPharmacy.Location = new System.Drawing.Point(378, 283);
            this.btnPharmacy.Name = "btnPharmacy";
            this.btnPharmacy.Size = new System.Drawing.Size(161, 56);
            this.btnPharmacy.TabIndex = 4;
            this.btnPharmacy.Text = "Pharmacy Stores";
            this.btnPharmacy.UseVisualStyleBackColor = false;
            this.btnPharmacy.Click += new System.EventHandler(this.btnPharmacy_Click);
            // 
            // lblDisplayBox1
            // 
            this.lblDisplayBox1.AutoSize = true;
            this.lblDisplayBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lblDisplayBox1.Location = new System.Drawing.Point(8, 25);
            this.lblDisplayBox1.Name = "lblDisplayBox1";
            this.lblDisplayBox1.Size = new System.Drawing.Size(117, 13);
            this.lblDisplayBox1.TabIndex = 5;
            this.lblDisplayBox1.Text = "MISSISSAUGA GUIDE";
            // 
            // lblDetails1
            // 
            this.lblDetails1.AutoSize = true;
            this.lblDetails1.Location = new System.Drawing.Point(27, 70);
            this.lblDetails1.Name = "lblDetails1";
            this.lblDetails1.Size = new System.Drawing.Size(0, 13);
            this.lblDetails1.TabIndex = 6;
            // 
            // lblDetails2
            // 
            this.lblDetails2.AutoSize = true;
            this.lblDetails2.Location = new System.Drawing.Point(27, 214);
            this.lblDetails2.Name = "lblDetails2";
            this.lblDetails2.Size = new System.Drawing.Size(0, 13);
            this.lblDetails2.TabIndex = 7;
            // 
            // lblDetails3
            // 
            this.lblDetails3.AutoSize = true;
            this.lblDetails3.Location = new System.Drawing.Point(27, 363);
            this.lblDetails3.Name = "lblDetails3";
            this.lblDetails3.Size = new System.Drawing.Size(0, 13);
            this.lblDetails3.TabIndex = 8;
            // 
            // lbldetails4
            // 
            this.lbldetails4.AutoSize = true;
            this.lbldetails4.Location = new System.Drawing.Point(672, 70);
            this.lbldetails4.Name = "lbldetails4";
            this.lbldetails4.Size = new System.Drawing.Size(0, 13);
            this.lbldetails4.TabIndex = 9;
            // 
            // lblDetails5
            // 
            this.lblDetails5.AutoSize = true;
            this.lblDetails5.Location = new System.Drawing.Point(672, 214);
            this.lblDetails5.Name = "lblDetails5";
            this.lblDetails5.Size = new System.Drawing.Size(0, 13);
            this.lblDetails5.TabIndex = 10;
            // 
            // lbldetails6
            // 
            this.lbldetails6.AutoSize = true;
            this.lbldetails6.Location = new System.Drawing.Point(672, 363);
            this.lbldetails6.Name = "lbldetails6";
            this.lbldetails6.Size = new System.Drawing.Size(0, 13);
            this.lbldetails6.TabIndex = 11;
            // 
            // Rangebox
            // 
            this.Rangebox.Location = new System.Drawing.Point(388, 61);
            this.Rangebox.Margin = new System.Windows.Forms.Padding(2);
            this.Rangebox.Name = "Rangebox";
            this.Rangebox.Size = new System.Drawing.Size(153, 20);
            this.Rangebox.TabIndex = 12;
            this.Rangebox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Resetbtn
            // 
            this.Resetbtn.Location = new System.Drawing.Point(597, 283);
            this.Resetbtn.Name = "Resetbtn";
            this.Resetbtn.Size = new System.Drawing.Size(75, 23);
            this.Resetbtn.TabIndex = 15;
            this.Resetbtn.Text = "Reset";
            this.Resetbtn.UseVisualStyleBackColor = true;
            this.Resetbtn.Click += new System.EventHandler(this.Resetbtn_Click);
            // 
            // Startbtn
            // 
            this.Startbtn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Startbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startbtn.Location = new System.Drawing.Point(577, 261);
            this.Startbtn.Name = "Startbtn";
            this.Startbtn.Size = new System.Drawing.Size(123, 67);
            this.Startbtn.TabIndex = 16;
            this.Startbtn.Text = "Start";
            this.Startbtn.UseVisualStyleBackColor = false;
            this.Startbtn.Click += new System.EventHandler(this.Startbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(388, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Enter # of Locations (1-6)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(962, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Startbtn);
            this.Controls.Add(this.Resetbtn);
            this.Controls.Add(this.Rangebox);
            this.Controls.Add(this.lbldetails6);
            this.Controls.Add(this.lblDetails5);
            this.Controls.Add(this.lbldetails4);
            this.Controls.Add(this.lblDetails3);
            this.Controls.Add(this.lblDetails2);
            this.Controls.Add(this.lblDetails1);
            this.Controls.Add(this.lblDisplayBox1);
            this.Controls.Add(this.btnPharmacy);
            this.Controls.Add(this.btnGasStations);
            this.Controls.Add(this.btnSportsCentres);
            this.Controls.Add(this.btnGroceryStores);
            this.Controls.Add(this.lblDisplayBox);
            this.Name = "Form1";
            this.Text = "My City; MIssissauga";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDisplayBox;
        private System.Windows.Forms.Button btnGroceryStores;
        private System.Windows.Forms.Button btnSportsCentres;
        private System.Windows.Forms.Button btnGasStations;
        private System.Windows.Forms.Button btnPharmacy;
        private System.Windows.Forms.Label lblDisplayBox1;
        private System.Windows.Forms.Label lblDetails1;
        private System.Windows.Forms.Label lblDetails2;
        private System.Windows.Forms.Label lblDetails3;
        private System.Windows.Forms.Label lbldetails4;
        private System.Windows.Forms.Label lblDetails5;
        private System.Windows.Forms.Label lbldetails6;
        private System.Windows.Forms.TextBox Rangebox;
        private System.Windows.Forms.Button Resetbtn;
        private System.Windows.Forms.Button Startbtn;
        private System.Windows.Forms.Label label1;
    }
}

